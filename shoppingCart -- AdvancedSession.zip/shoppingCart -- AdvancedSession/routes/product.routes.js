var express=require("express");
const { validateToken } = require("../utils");

var productRouter=express.Router();
var productsArr=[
    {productId:101,productName:"Ipad"},
    {productId:102,productName:"IMac"},
    {productId:103,productName:"Iphone"}
];
productRouter.use((req,res,next)=>{
    console.log("Middleware in products route");
    next();
})
//productRouter.use(validateToken);
productRouter.get("/",(request,response)=>{
    response.send(productsArr);
    //response.send(JSON.stringify(productsArr));
});
productRouter.post("/",validateToken,(req,res)=>{
    console.log("Inside post request of /products")
    // insert a record
    var productToBeInserted=req.body;
    productsArr.push(productToBeInserted);
    res.send(productsArr);
    //res.json(productsArr)
    //res.send(JSON.stringify(productsArr));
    
})
module.exports=productRouter;