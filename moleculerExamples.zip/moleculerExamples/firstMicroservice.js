const {ServiceBroker}=require("moleculer");

const broker=new ServiceBroker();

broker.createService({
    name:"math",
    actions:{
        // public functions of service
        //...
        add(ctx)
        {
            // ctx -- context; state of service
            return ctx.params.n1+ctx.params.n2
        }
    },
    methods:{
        // private functions of service

    }
});

broker.start()
.then(()=>{
    return broker.call("math.add",{n1:10,n2:20})
})
.then((result)=>{console.log(`Sum of 10 and 20 is ${result}`)})
.catch((err)=>{console.log("Error in starting the service")})